from umqtt.simple import MQTTClient
from microdot import Microdot, Response, send_file
from microdot_utemplate import render_template
from machine import Pin
import machine, neopixel
import json
# boot.py -- run on boot-up
import network
# Replace the following with your WIFI Credentials
SSID = "TskoliVESM"
SSI_PASSWORD = "Fallegurhestur"

def do_connect():
    import network
    sta_if = network.WLAN(network.STA_IF)
    if not sta_if.isconnected():
        print('connecting to network...')
        sta_if.active(True)
        sta_if.connect(SSID, SSI_PASSWORD)
        while not sta_if.isconnected():
            pass
    print('Connected! Network config:', sta_if.ifconfig())
    
print("Connecting to your wifi...")
do_connect()

TOPIC = "1606"

# BROKER_ID = "10.201.48.85"
BROKER_ID = "test.mosquitto.org"
client_id = "HalloGeir"

mqtt_client = MQTTClient(client_id, BROKER_ID, keepalive=60)
mqtt_client.connect()

def regnbogi():
    return {"1" : (128, 0, 0), "2" : (160, 100, 0), "3" : (200, 30, 0), "4" : (0, 128, 0), "5" : (0, 0, 128), "6" : (60, 10, 100), "7" : (128, 0, 128), "8" : (140, 64, 140)}

app = Microdot()
Response.default_content_type = 'text/html'
@app.route('/', methods=['GET', 'POST'])
def index(req):
    name = "Unknown"
    print("form", req.form)
    if req.method == "POST":
        listi = []
        for i in range(8):
            name = req.form.get(f"name{str(i)}")
            print(f"name{str(i)}")
            nafn = name
            print(name)
            dic = nafn[1]
            red2 = nafn[2]
            green1 = nafn[3]
            green2 = nafn[4]
            blue1 = nafn[5]
            blue2 = nafn[6]
            red= dic + red2
            green = green1 + green2
            blue = blue1 + blue2
            
            dicto = {"red" : int(red, 16), "green" : int(green, 16), "blue" : int(blue, 16)}
            print(dicto)
            listi.append(dicto)
        sendi = json.dumps(listi)
        print(sendi)
        mqtt_client.publish(TOPIC, sendi.encode())
    else:
        print("get")
        return send_file("/templates/index.html")
if __name__ == '__main__':
    app.run(debug=True)